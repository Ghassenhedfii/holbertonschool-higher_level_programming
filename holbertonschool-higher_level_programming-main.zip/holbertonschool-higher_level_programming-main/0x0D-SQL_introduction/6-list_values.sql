-- all rows of the table.
SELECT * FROM first_table;
