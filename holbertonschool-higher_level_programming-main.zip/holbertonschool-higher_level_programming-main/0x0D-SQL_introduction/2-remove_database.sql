-- script that deletes the database hbtn_0c_0 in your MySQL server
DROP DATABASE If EXISTS hbtn_0c_0;

