-- script that lists all databases of your MySQL server.
SHOW DATABASES;
