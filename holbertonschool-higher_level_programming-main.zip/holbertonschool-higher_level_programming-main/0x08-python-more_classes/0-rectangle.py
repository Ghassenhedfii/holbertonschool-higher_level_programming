#!/usr/bin/python3
"""This module creates an empty class named Rectangle"""


class Rectangle:
    """An empty class"""
    pass
