#!/usr/bin/python3
str = "Holberton School"
print("{}\n{}".format(3 * str, str[:9]))
