#!/usr/bin/node
const myVar = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
for (let i = 0; i < myVar.length; i++) {
  console.log(myVar[i]);
}
