#!/usr/bin/node
const s1 = process.argv[2];
const s2 = process.argv[3];
console.log(s1 + ' is ' + s2);
