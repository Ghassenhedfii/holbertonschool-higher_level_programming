#!/bin/bash
# Sends a DELETE request to URL and displays the body of the response
curl -sX DELETE "$1"
