#!/bin/bash
# takes url, send a GET and display the body
curl -sL GET "$1"
