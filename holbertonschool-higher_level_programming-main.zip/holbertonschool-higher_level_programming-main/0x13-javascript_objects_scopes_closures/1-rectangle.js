#!/usr/bin/node
module.exports = class Rectangle {
  constructor (width, height) {
    this.width = width;
    this.height = height;
  }
};
