window.$('header').css('color', '#FF0000');
