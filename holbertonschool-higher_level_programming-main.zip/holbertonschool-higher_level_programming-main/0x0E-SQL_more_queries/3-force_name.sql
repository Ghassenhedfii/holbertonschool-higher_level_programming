-- creates a table force_name where one variable cannot be NULL
CREATE TABLE IF NOT EXISTS force_name(id INT, name VARCHAR(256) NOT NULL);
