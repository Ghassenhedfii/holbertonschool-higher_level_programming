#!/usr/bin/python3
"""
lookup function
"""


def lookup(obj):
    """function that returns the list of attributes and methods of an object"""
    return dir(obj)
