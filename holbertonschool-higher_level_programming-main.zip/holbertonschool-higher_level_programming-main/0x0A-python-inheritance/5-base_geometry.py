#!/usr/bin/python3
""" Base_geometry module"""


class BaseGeometry():
    """empty class"""
    pass
