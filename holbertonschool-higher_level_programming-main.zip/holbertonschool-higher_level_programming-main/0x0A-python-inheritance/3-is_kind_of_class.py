#!/usr/bin/python3
"""
is_kind_of_class
"""


def is_kind_of_class(obj, a_class):
    """ function to compare object to instance """
    return(isinstance(obj, a_class))
