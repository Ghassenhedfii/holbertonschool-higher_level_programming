#!/usr/bin/python3
"""This module creates an empty class named Square"""


class Square:
    """An empty class"""
    pass
